﻿namespace WebApplicationAbad.Areas.StudentCourses.Models
{
    public class ResetPasswordModel
    {
        public string Email { get; set; }
    }

}
