﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Hosting;
using WebApplicationAbad.Areas.AdminCoursesData.Models;
using WebApplicationAbad.Areas.AdminManageData.Data;
using WebApplicationAbad.Data;
using WebApplicationAbad.Repository.RepositoryInterface;
using static System.Net.Mime.MediaTypeNames;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;


namespace WebApplicationAbad.Areas.AdminCoursesData.Controllers
{
    [Area("AdminCoursesData")]
    public class ArticleController : Controller
    {
        private readonly IUnitOfWork work;
        private readonly ApplicationDbContext context;
        private readonly IHostingEnvironment host;

        public void FillLast(int IndexValue = 1)
        {

            var datas = context.CoursesTypes.Where(b => !b.IsDelete && !b.IsHide);
            SelectList list = new SelectList(datas, "Code", "EnglishName");


            ViewBag.FillData = list;

        }

        public ArticleController(IUnitOfWork work, ApplicationDbContext context, IHostingEnvironment host)
        {
            this.work = work;
            this.context = context;
            this.host = host;

        }
        public IActionResult ArticleIndex()
        {
            var Art = context.Article.Where(b => !b.IsDelete).OrderByDescending(b => b.PublishDate).ToList();
            return View(Art);
        }

        public IActionResult GetArt(int Id)
        {
            return Redirect($"/Home/GetReadArticle/{Id}");
        }
        
        public IActionResult ArticleCreate(int id)
        {
            var FindId = context.Article.Find(id);

            if (FindId == null)
            {
                ViewBag.coursesStatus = "ارسال";
                ViewBag.BoolValue = true;
                FillLast();

            }
            else
            {
                ViewBag.coursesStatus = "تعديل";
                ViewBag.BoolValue = false;
                FillLast(id);
                return View(FindId);
            }

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ArticleCreate(Article article, int id)
        {

            var FindId = context.Article.Find(id);
            var app = context.Article.OrderBy(m => m.Id).LastOrDefault();
            string file = string.Empty;
            string newfile = string.Empty;
            var apps = new Article();
            string Paths = string.Empty;
            string? EmployeeId = Request.Cookies["EmployeeId"];
            Employee employee = context.Employees.FirstOrDefault(b => b.Token == EmployeeId);
            if (FindId == null)
            {

                if (article.FormFiles != null && article.FormFiles.Length > 0)
                {
                    string Upload = Path.Combine(host.WebRootPath, "Admin", "ImageArticle");

                    if (!Directory.Exists(Upload))
                    {
                        Directory.CreateDirectory(Upload);
                    }

                    file = article.FormFiles.FileName;

                    string extension = Path.GetExtension(article.FormFiles.FileName);

                    if (app != null)
                    {
                        newfile = (app.Id + 1).ToString() + extension;
                        Paths = Path.Combine(Upload, newfile);
                        article.FormFiles.CopyTo(new FileStream(Paths, FileMode.Create));
                        article.Iamge = newfile;
                    }
                    else
                    {
                        context.Article.Add(article);
                        context.SaveChanges();
                        apps = context.Article.OrderBy(m => m.Id).LastOrDefault();
                        newfile = apps.Id.ToString() + extension;
                        apps.Iamge = newfile;
                        Paths = Path.Combine(Upload, newfile);
                        article.FormFiles.CopyTo(new FileStream(Paths, FileMode.Create));
                        article.Iamge = newfile;

                    }

                }
                if (app == null)
                {
                    article.LastUpdateUserCode = employee.Email;
                    article.LastUpdateDate = DateTime.Now;
                    context.Article.Update(apps);
                    context.SaveChanges();


                }
                else
                {
                    context.Article.Add(article);
                    context.SaveChanges();

                }
                ViewBag.coursesStatus = "Submit";
                ViewBag.BoolValue = true;
                return Redirect("ArticleCreate");
            }

            //Update Data
            else
            {
                context.Article.Update(FindId);
                context.SaveChanges();
                if (article.FormFiles != null && article.FormFiles.Length > 0)
                {

                    string Upload = Path.Combine(host.WebRootPath, "Admin", "ImageArticle");
                    if (!Directory.Exists(Upload))
                    {
                        Directory.CreateDirectory(Upload);
                    }
                    string fileName = article.FormFiles.FileName;
                    string newFileName = article.Id.ToString();
                    string newFilePath = Path.Combine(Upload, newFileName);


                    string[] existingFiles = { newFilePath + ".jpg", newFilePath + ".png" };
                    foreach (string existingFile in existingFiles)
                    {
                        if (System.IO.File.Exists(existingFile))
                        {
                            System.IO.File.Delete(existingFile);
                        }
                    }


                    newFilePath += Path.GetExtension(fileName);
                    using (FileStream fileStream = new FileStream(newFilePath, FileMode.Create))
                    {
                        article.FormFiles.CopyTo(fileStream);
                    }
                    FindId.Iamge = newFileName + Path.GetExtension(fileName);
                }

                FindId.TitleHeader = article.TitleHeader;
                FindId.Title = article.Title;
                FindId.Absractation = article.Absractation;
                FindId.TitelSubject2 = article.TitelSubject2;
                FindId.ContentSubject2 = article.ContentSubject2;
                FindId.TitleContont3 = article.TitleContont3;
                FindId.TitleSubject3 = article.TitleSubject3;
                FindId.Author = article.Author;
                FindId.IsHide = article.IsHide;
                FindId.LastUpdateUserCode = article.LastUpdateUserCode;
                FindId.LastUpdateDate = article.LastUpdateDate;

                context.Article.Update(FindId);
                context.SaveChanges();
                ViewBag.coursesStatus = "تعديل";
                ViewBag.BoolValue = false;
                return RedirectToAction("ArticleCreate");
            }
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ArticleIndex(Article article, int id)
        {
            var fintID = context.Article.Find(id);
            string? EmployeeId = Request.Cookies["EmployeeId"];
            Employee employee = context.Employees.FirstOrDefault(b => b.Token == EmployeeId);

            if (fintID != null)
            {
                fintID.IsDelete = true;
                fintID.LastUpdateUserCode = employee.Email;
                fintID.LastUpdateDate = DateTime.Now;
                context.Article.Update(fintID);
                context.SaveChanges();
            }
            return Redirect("ArticleIndex");
        }
    }

}
