﻿

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static System.Net.Mime.MediaTypeNames;
using System.Text;

namespace WebApplicationAbad.Areas.AdminCoursesData.Controllers
{
    [Area("AdminCoursesData")]
    public class HomeController : Controller
    {


        public IActionResult Index()
        {
            string email;
            if (HttpContext.Session.TryGetValue("AdminEmail", out byte[] value))
            {
                email = Encoding.UTF8.GetString(value);
                return View();
            }
            else
            {
                // The key "AdminEmail" does not exist in the session.
                // You can handle the case when the session variable is not present.

                return Redirect("/Identity/Account/login");
            }


        }
    }
}
