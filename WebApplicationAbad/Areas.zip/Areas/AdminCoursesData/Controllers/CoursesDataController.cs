﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using NuGet.Packaging.Signing;
using System.Drawing;
using System.Text;
using WebApplicationAbad.Areas.AdminCoursesData.Models;
using WebApplicationAbad.Areas.AdminManageData.Data;
using WebApplicationAbad.Data;
using WebApplicationAbad.Repository.RepositoryInterface;
using static System.Net.Mime.MediaTypeNames;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;


namespace WebApplicationAbad.Areas.AdminCoursesData.Controllers
{
    [Area("AdminCoursesData")]
    public class CoursesDataController : Controller
    {
        private readonly IUnitOfWork work;
        private readonly ApplicationDbContext context;
        private readonly IHostingEnvironment host;

        public CoursesDataController(IUnitOfWork work, ApplicationDbContext context, IHostingEnvironment host)
        {
            this.work = work;
            this.context = context;
            this.host = host;
        }

        public void FillLast(int IndexValue = 1)
        {

            var datas = context.CoursesTypes.Where(b => !b.IsDelete && !b.IsHide);
            SelectList list = new SelectList(datas, "Code", "EnglishName");
             

            ViewBag.FillData = list;

        }
        public IActionResult GetCoursesDataIndex()
        {
            var allData = context.CoursesData.Where(b => !b.IsDelete).ToList();
            return View(allData);

        }

        public IActionResult GetCoursesDataDetils(int id)
        {
			var FindId = work.CoursesData.GetByID(id);
			return View(FindId);
		}
        public IActionResult GetCoursesDataCreate(int id)
        {
            var FindId = work.CoursesData.GetByID(id);

            if (FindId == null)
            {
                ViewBag.coursesStatus = "ارسال";
                ViewBag.BoolValue = true;
                FillLast();
            }
            else
            {
                ViewBag.coursesStatus = "تعديل";
                ViewBag.BoolValue = false;
                FillLast(id);
                return View(FindId);
            }

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [RequestSizeLimit(200 * 1024 * 1024)]
        public IActionResult GetCoursesDataCreate(CoursesData coursesData, int id)
        {

            var FindId = work.CoursesData.GetByID(id);
            var app = context.CoursesData.OrderBy(m => m.Id).LastOrDefault();
            string file = string.Empty;
            string newfile = string.Empty;
            var apps = new CoursesData();
            string Paths = string.Empty;
            string Upload = string.Empty;
            string UploadFiles = string.Empty;
            string UploadCoursesType = string.Empty;
            string extension = string.Empty;
            string extensions = string.Empty;
            string newfileData = string.Empty;
            string? EmployeeId = Request.Cookies["EmployeeId"];
            Employee employee = context.Employees.FirstOrDefault(b => b.Token == EmployeeId);

            bool IsFiles = false;
            bool IsImage = false;

            if (FindId == null)
            {
                if (coursesData.FormFileData != null && coursesData.FormFileData.Length > 0)
                {
                    IsFiles = true;
                    extension = Path.GetExtension(coursesData.FormFileData.FileName);
                    if (coursesData.FormFileData != null && coursesData.FormFileData.Length > 0)
                    {
                        UploadFiles = Path.Combine(host.WebRootPath, "Admin", "CoursesDataFiles");

                        if (!Directory.Exists(UploadFiles))
                        {
                            Directory.CreateDirectory(UploadFiles);
                        }

                        UploadCoursesType = Path.Combine(host.WebRootPath, "Admin", "CoursesDataFiles", coursesData.CoursesTypeId.ToString());
                        if (!Directory.Exists(UploadCoursesType))
                        {
                            Directory.CreateDirectory(UploadCoursesType);
                        }
                    }
                }
                if (coursesData.FormFiles != null && coursesData.FormFiles.Length > 0)
                {
                    IsImage = true;
                    extensions = Path.GetExtension(coursesData.FormFiles.FileName);
                    Upload = Path.Combine(host.WebRootPath, "Admin", "CoursesDataImage");
                    if (!Directory.Exists(Upload))
                    {
                        Directory.CreateDirectory(Upload);
                    }
                }

                file = coursesData.FormFiles.FileName;



                if (app != null)
                {
                    if (IsImage && IsFiles)
                    {

                        newfile =coursesData.HeaderEn +"-"+ (app.Id + 1).ToString() + extension;
                        newfileData = (app.Id + 1).ToString() + extensions;
                        string newfilePath = (app.Id + 1).ToString();

                        string FileDataCourses = Path.Combine(host.WebRootPath, "Admin", "CoursesDataFiles", coursesData.CoursesTypeId.ToString(), newfilePath);
                        Directory.CreateDirectory(FileDataCourses);
                        string UploadCoursesData = Path.Combine(host.WebRootPath, "Admin", "CoursesDataFiles", coursesData.CoursesTypeId.ToString(), newfilePath);

                        Paths = Path.Combine(UploadCoursesData, newfile);
                        string Pathse = Path.Combine(Upload, newfileData);

                        coursesData.FormFileData.CopyTo(new FileStream(Paths, FileMode.Create));
                        coursesData.FormFiles.CopyTo(new FileStream(Pathse, FileMode.Create));

                        coursesData.FilesData = newfile;
                        coursesData.Image = newfileData;

                        // coursesData.UserCode = employee.Email;
                        coursesData.UserCode = "111";
                        coursesData.CreatedDate = DateTime.Now;
                        work.CoursesData.AddNewRow(coursesData);
                        
                        

                    }
                    else
                    {
                        newfile = (app.Id + 1).ToString() + extensions;
                        string newfilePath = apps.Id.ToString();
                        string Pathse = Path.Combine(Upload, newfile);
                        coursesData.FormFiles.CopyTo(new FileStream(Pathse, FileMode.Create));

                        coursesData.Image = newfileData;
                        //coursesData.UserCode = employee.Email;
                        coursesData.UserCode = "111";
                        coursesData.CreatedDate = DateTime.Now;
                        work.CoursesData.AddNewRow(coursesData);
                    }
                }

                else
                {
                    if (IsImage && IsFiles)
                    {
                        work.CoursesData.AddNewRow(coursesData);
                        apps = context.CoursesData.OrderBy(m => m.Id).LastOrDefault();
                        newfile = coursesData.HeaderEn+ "-" + (apps.Id + 1).ToString() + extension;
                        string newfilePath = apps.Id.ToString();

                        string FileDataCourses = Path.Combine(host.WebRootPath, "Admin", "CoursesDataFiles", coursesData.CoursesTypeId.ToString(), apps.Id.ToString());
                        Directory.CreateDirectory(FileDataCourses);
                        string UploadCoursesData = Path.Combine(host.WebRootPath, "Admin", "CoursesDataFiles", coursesData.CoursesTypeId.ToString(), newfilePath);
                        Paths = Path.Combine(UploadCoursesData, newfile);
                        coursesData.FormFileData.CopyTo(new FileStream(Paths, FileMode.Create));


                        apps = context.CoursesData.OrderBy(m => m.Id).LastOrDefault();
                        newfileData = apps.Id.ToString() + extensions;
                        Paths = Path.Combine(Upload, newfileData);
                        coursesData.FormFiles.CopyTo(new FileStream(Paths, FileMode.Create));

                        apps.Image = newfileData;
                        apps.FilesData = newfile;

                        work.CoursesData.UpdateRow(apps);
                    }

                    else
                    {
                        work.CoursesData.AddNewRow(coursesData);
                        apps = context.CoursesData.OrderBy(m => m.Id).LastOrDefault();
                        newfile = apps.Id.ToString() + extension;
                        string newfilePath = apps.Id.ToString();

                        apps = context.CoursesData.OrderBy(m => m.Id).LastOrDefault();
                        newfileData = apps.Id.ToString() + extensions;
                        Paths = Path.Combine(Upload, newfileData);
                        coursesData.FormFiles.CopyTo(new FileStream(Paths, FileMode.Create));

                        apps.Image = newfileData;
                        // apps.UserCode = employee.Email;
                        coursesData.UserCode = "111";
                        apps.CreatedDate = DateTime.Now;
                        work.CoursesData.UpdateRow(apps);

                    }
                }
                return Redirect("GetCoursesDataIndex");

            }

            //Update Data
            else
            {


                if (coursesData.FormFileData != null && coursesData.FormFileData.Length > 0)
                {
                    IsFiles = true;
                    extension = Path.GetExtension(coursesData.FormFileData.FileName);
                    if (coursesData.FormFileData != null && coursesData.FormFileData.Length > 0)
                    {
                        UploadFiles = Path.Combine(host.WebRootPath, "Admin", "CoursesDataFiles");

                        if (!Directory.Exists(UploadFiles))
                        {
                            Directory.CreateDirectory(UploadFiles);
                        }

                        UploadCoursesType = Path.Combine(host.WebRootPath, "Admin", "CoursesDataFiles");
                        if (!Directory.Exists(UploadCoursesType))
                        {
                            Directory.CreateDirectory(UploadCoursesType);
                        }
                    }
                }

                if (coursesData.FormFiles != null && coursesData.FormFiles.Length > 0)
                {
                    IsImage = true;
                    extensions = Path.GetExtension(coursesData.FormFiles.FileName);
                    Upload = Path.Combine(host.WebRootPath, "Admin", "CoursesDataImage");
                    if (!Directory.Exists(Upload))
                    {
                        Directory.CreateDirectory(Upload);
                    }
                }

                    if (IsImage)
                    {
                        string fileName = coursesData.FormFiles.FileName;
                        string newFileName = coursesData.Id.ToString();
                        string newFilePath = Path.Combine(Upload, newFileName);


                        string[] existingFiles = { newFilePath + ".jpg", newFilePath + ".png" };
                        foreach (string existingFile in existingFiles)
                        {
                            if (System.IO.File.Exists(existingFile))
                            {
                                System.IO.File.Delete(existingFile);
                            }
                        }


                        newFilePath += Path.GetExtension(fileName);
                        using (FileStream fileStream = new FileStream(newFilePath, FileMode.Create))
                        {
                            coursesData.FormFiles.CopyTo(fileStream);
                        }
                        FindId.Image = newFileName + Path.GetExtension(fileName);
                    }
                    if (IsFiles)
                    {
                        string UploadCoursesData = Path.Combine(host.WebRootPath, "Admin", "CoursesDataFiles", coursesData.CoursesTypeId.ToString(), id.ToString());
                       
                        string fileNameForm = coursesData.FormFileData.FileName;
                        string newFileNameForm = coursesData.HeaderEn + "-" + coursesData.Id.ToString();
                        string newFilePathForm = Path.Combine(UploadCoursesData, newFileNameForm);


                          string[] files = Directory.GetFiles(UploadCoursesData);
                          foreach (string filel in files)
                          {
                              System.IO.File.Delete(filel);
                          }

                        newFilePathForm += Path.GetExtension(fileNameForm);
                        using (FileStream fileStream = new FileStream(newFilePathForm, FileMode.Create))
                        {
                            coursesData.FormFileData.CopyTo(fileStream);
                        }
                    FindId.FilesData = newFileNameForm;
                    }

                    FindId.HeaderAr = coursesData.HeaderAr;
                    FindId.HeaderEn = coursesData.HeaderEn;
                    FindId.SummaryAr = coursesData.SummaryAr;
                    FindId.SammaryEn = coursesData.SammaryEn;
                    FindId.TargetAr = coursesData.TargetAr;
                    FindId.TargetEn = coursesData.TargetEn;
                    FindId.DetailsAr = coursesData.DetailsAr;
                    FindId.GoalsAr = coursesData.GoalsAr;
                    FindId.GoalsEn = coursesData.GoalsEn;
                    FindId.TestAr= coursesData.TestAr;
                    FindId.FromalutetestAr = coursesData.FromalutetestAr;
                    FindId.PriceM = coursesData.PriceM;
                    FindId.PriceNoM = coursesData.PriceNoM;
                    FindId.Nots = coursesData.Nots;
                    FindId.Price = coursesData.Price;
                    FindId.IsHide = coursesData.IsHide;
              //  FindId.LastUpdateUserCode = employee.Email;
                FindId.LastUpdateUserCode = "111";
                    FindId.LastUpdateDate = DateTime.Now;
                    work.CoursesData.UpdateRow(FindId);
                    ViewBag.coursesStatus = "تعديل";
                    ViewBag.BoolValue = false;
                    return RedirectToAction("GetCoursesDataIndex");

                }
            }
        [HttpPost]
        [ValidateAntiForgeryToken]

        public IActionResult GetCoursesDataIndex(int id)
        {
            var fintID = work.CoursesData.GetByID(id);
            string? EmployeeId = Request.Cookies["EmployeeId"];
            Employee employee = context.Employees.FirstOrDefault(b => b.Token == EmployeeId);

            if (fintID != null)
            {
                fintID.IsDelete = true;
                fintID.LastUpdateDate = DateTime.Now;
                fintID.UserCode = employee.Email;
                work.CoursesData.UpdateRow(fintID);
            }
            return Redirect("GetCoursesDataIndex");
        }

        }
    }







