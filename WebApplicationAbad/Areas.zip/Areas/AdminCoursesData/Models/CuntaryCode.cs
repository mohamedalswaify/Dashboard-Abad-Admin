﻿namespace WebApplicationAbad.Areas.AdminCoursesData.Models
{
    public class CuntaryCode
    {
        public int Id { get; set; }

        public string CountryName { get; set; }

        public string AreaCun { get; set; }

        public string NotationCun { get; set; }
    }
}
