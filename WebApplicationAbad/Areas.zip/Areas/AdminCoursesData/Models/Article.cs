﻿using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplicationAbad.Areas.AdminCoursesData.Models
{
  
        public class Article
        {
        public int Id { get; set; }

        public string? TitleHeader { get; set; }

        public string? Title { get; set; }

        public string? ContetntTitle { get; set; }

        public string? Absractation { get; set; }

        public string? TitelSubject2 { get; set; }

        public string? ContentSubject2 { get; set; }

        public string? TitleSubject3 { get; set; }

        public string? TitleContont3 { get; set; }

        public string? Author { get; set; }

        public string? Iamge { get; set; }
       
        [NotMapped]
        public IFormFile FormFiles { get; set; }

        public bool IsHide { get; set; } = false;

        public bool IsDelete { get; set; } = false;

        public string? UserUpdaue { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.Now;


        public string? LastUpdateUserCode { get; set; }

        public DateTime? LastUpdateDate { get; set; }


        public DateTime PublishDate { get; set; } = DateTime.Now;


        public int CoursesTypeCode { get; set; }

        public virtual CoursesType? CoursesType { get; set; }
            
        }
}
