﻿namespace WebApplicationAbad.Areas.AdminCoursesData.Models
{
    public class PayTabsCallbackModel
    {
        public int Id { get; set; }
        public string? AcquirerMessage { get; set; }
        public string? AcquirerRRN { get; set; }
        public string? CartId { get; set; }
        public string? CustomerEmail { get; set; }
        public string? RespCode { get; set; }
        public string? RespMessage { get; set; }
        public string? RespStatus { get; set; }
        public string? Token { get; set; }
        public string? TranRef { get; set; }
    }
}
